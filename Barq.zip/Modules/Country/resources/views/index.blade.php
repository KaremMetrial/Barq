<x-country::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('country.name') !!}</p>
</x-country::layouts.master>
