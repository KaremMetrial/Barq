<x-compaignparicipation::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('compaignparicipation.name') !!}</p>
</x-compaignparicipation::layouts.master>
