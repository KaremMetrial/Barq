<x-governorate::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('governorate.name') !!}</p>
</x-governorate::layouts.master>
