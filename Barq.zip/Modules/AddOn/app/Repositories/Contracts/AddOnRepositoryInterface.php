<?php

namespace Modules\AddOn\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepositoryInterface;
interface AddOnRepositoryInterface extends BaseRepositoryInterface
{

}
