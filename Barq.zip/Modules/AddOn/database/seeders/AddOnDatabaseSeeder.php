<?php

namespace Modules\AddOn\Database\Seeders;

use Illuminate\Database\Seeder;

class AddOnDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
