<x-banner::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('banner.name') !!}</p>
</x-banner::layouts.master>
