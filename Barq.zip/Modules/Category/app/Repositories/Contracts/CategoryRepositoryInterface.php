<?php

namespace Modules\Category\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepositoryInterface;
interface CategoryRepositoryInterface extends BaseRepositoryInterface
{

}
