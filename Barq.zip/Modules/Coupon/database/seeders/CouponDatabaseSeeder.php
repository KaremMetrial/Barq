<?php

namespace Modules\Coupon\Database\Seeders;

use Illuminate\Database\Seeder;

class CouponDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
