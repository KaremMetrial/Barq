<x-coupon::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('coupon.name') !!}</p>
</x-coupon::layouts.master>
