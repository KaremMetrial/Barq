<?php

return [
    'name' => 'Conversation',
];
