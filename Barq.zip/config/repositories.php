<?php
return [
    // Bind interfaces to their implementations
    App\Repositories\Contracts\UserRepositoryInterface::class => App\Repositories\UserRepository::class,
];
