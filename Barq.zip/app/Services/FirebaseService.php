<?php
namespace App\Services;

use Illuminate\Support\Facades\Log;
use Kreait\Firebase\Contract\Messaging;
use Kreait\Firebase\Messaging\CloudMessage;
use Kreait\Firebase\Messaging\Notification as FirebaseNotification;
use Kreait\Firebase\Exception\Messaging\InvalidMessage;

class FirebaseService
{
    public function __construct(protected Messaging $messaging)
    {
        $this->messaging = $messaging;
    }

    /**
     * Send notification to device tokens
     *
     * @param string|array|\Illuminate\Support\Collection $deviceTokens Single token, array, or Collection
     * @param string $title Notification title
     * @param string $body Notification body
     * @param array $data Additional data payload
     * @return bool True if at least one notification sent successfully
     */
    public function sendToDevice($deviceTokens, string $title, string $body, array $data = []): bool
    {
        // تحويل الـ Collection أو string إلى array من التوكنات
        if ($deviceTokens instanceof \Illuminate\Support\Collection) {
            $tokens = $deviceTokens->toArray();
        } elseif (is_string($deviceTokens)) {
            $tokens = [$deviceTokens];
        } elseif (is_array($deviceTokens)) {
            $tokens = $deviceTokens;
        } else {
            Log::warning('Invalid device tokens type', ['device_tokens' => $deviceTokens]);
            return false;
        }

        // إذا لا توجد توكنات صالحة
        if (empty($tokens)) {
            Log::warning('No device tokens provided for Firebase notification', [
                'title' => $title,
                'body' => $body,
                'data' => $data,
            ]);
            return false;
        }

        try {
            $message = CloudMessage::new()
                ->withNotification(FirebaseNotification::create($title, $body))
                ->withData($data);

            $sendReport = $this->messaging->sendMulticast($message, $tokens);

            Log::info('Firebase notification sent successfully', [
                'device_tokens' => $tokens,
                'title' => $title,
                'body' => $body,
                'data' => $data,
                'success_count' => $sendReport->successes()->count(),
                'failure_count' => $sendReport->failures()->count(),
            ]);

            Log::info('Firebase notification sent ', [
                'success_count' => $sendReport->toJson(),
            ]);

            return $sendReport->successes()->count() > 0;
        } catch (InvalidMessage $e) {
            Log::error('Failed to send Firebase notification', [
                'device_tokens' => $tokens,
                'title' => $title,
                'body' => $body,
                'data' => $data,
                'error' => $e->getMessage(),
            ]);
            return false;
        }
    }
}
