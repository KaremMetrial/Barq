<?php

use Illuminate\Support\Facades\Route;
use Modules\AddOn\Http\Controllers\AddOnController;

