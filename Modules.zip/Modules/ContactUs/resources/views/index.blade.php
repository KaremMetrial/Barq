<x-contactus::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('contactus.name') !!}</p>
</x-contactus::layouts.master>
