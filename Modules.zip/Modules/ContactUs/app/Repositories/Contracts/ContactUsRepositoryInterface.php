<?php

namespace Modules\ContactUs\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepositoryInterface;
interface ContactUsRepositoryInterface extends BaseRepositoryInterface
{

}
