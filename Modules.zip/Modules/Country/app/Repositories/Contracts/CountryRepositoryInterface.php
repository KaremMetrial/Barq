<?php

namespace Modules\Country\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepositoryInterface;
interface CountryRepositoryInterface extends BaseRepositoryInterface
{

}
