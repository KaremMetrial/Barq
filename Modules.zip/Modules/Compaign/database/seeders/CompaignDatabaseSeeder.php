<?php

namespace Modules\Compaign\Database\Seeders;

use Illuminate\Database\Seeder;

class CompaignDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
