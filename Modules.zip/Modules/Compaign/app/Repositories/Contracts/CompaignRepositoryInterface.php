<?php

namespace Modules\Compaign\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepositoryInterface;
interface CompaignRepositoryInterface extends BaseRepositoryInterface
{

}
