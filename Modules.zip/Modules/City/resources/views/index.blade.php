<x-city::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('city.name') !!}</p>
</x-city::layouts.master>
