<?php

namespace Modules\City\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepositoryInterface;
interface CityRepositoryInterface extends BaseRepositoryInterface
{

}
