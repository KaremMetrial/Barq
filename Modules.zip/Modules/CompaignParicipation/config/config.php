<?php

return [
    'name' => 'CompaignParicipation',
];
