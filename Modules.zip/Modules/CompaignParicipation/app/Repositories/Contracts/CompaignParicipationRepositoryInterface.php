<?php

namespace Modules\CompaignParicipation\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepositoryInterface;
interface CompaignParicipationRepositoryInterface extends BaseRepositoryInterface
{

}
