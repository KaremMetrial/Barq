<?php

namespace Modules\CompaignParicipation\Database\Seeders;

use Illuminate\Database\Seeder;

class CompaignParicipationDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
