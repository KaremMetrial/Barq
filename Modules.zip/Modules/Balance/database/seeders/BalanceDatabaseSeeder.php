<?php

namespace Modules\Balance\Database\Seeders;

use Illuminate\Database\Seeder;

class BalanceDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
