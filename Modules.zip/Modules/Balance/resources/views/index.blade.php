<x-balance::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('balance.name') !!}</p>
</x-balance::layouts.master>
