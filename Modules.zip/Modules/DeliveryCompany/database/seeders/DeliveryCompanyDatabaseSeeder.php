<?php

namespace Modules\DeliveryCompany\Database\Seeders;

use Illuminate\Database\Seeder;

class DeliveryCompanyDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
