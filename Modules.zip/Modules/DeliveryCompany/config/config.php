<?php

return [
    'name' => 'DeliveryCompany',
];
