<?php

namespace Modules\Conversation\Database\Seeders;

use Illuminate\Database\Seeder;

class ConversationDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
