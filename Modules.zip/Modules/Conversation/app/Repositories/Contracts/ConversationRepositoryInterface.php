<?php

namespace Modules\Conversation\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepositoryInterface;
interface ConversationRepositoryInterface extends BaseRepositoryInterface
{

}
