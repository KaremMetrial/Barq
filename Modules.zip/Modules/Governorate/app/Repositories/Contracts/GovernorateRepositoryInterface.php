<?php

namespace Modules\Governorate\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepositoryInterface;
interface GovernorateRepositoryInterface extends BaseRepositoryInterface
{

}
