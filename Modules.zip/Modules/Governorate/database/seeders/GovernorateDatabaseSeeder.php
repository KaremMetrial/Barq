<?php

namespace Modules\Governorate\Database\Seeders;

use Illuminate\Database\Seeder;

class GovernorateDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
