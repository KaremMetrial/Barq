<?php

return [
    'name' => 'Governorate',
];
