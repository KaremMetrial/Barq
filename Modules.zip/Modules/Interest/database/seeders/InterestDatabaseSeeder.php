<?php

namespace Modules\Interest\Database\Seeders;

use Illuminate\Database\Seeder;

class InterestDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
