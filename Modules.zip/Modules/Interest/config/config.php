<?php

return [
    'name' => 'Interest',
];
