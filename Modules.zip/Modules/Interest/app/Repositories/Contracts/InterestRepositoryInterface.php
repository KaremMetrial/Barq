<?php

namespace Modules\Interest\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepositoryInterface;
interface InterestRepositoryInterface extends BaseRepositoryInterface
{

}
