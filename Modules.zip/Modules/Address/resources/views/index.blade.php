<x-address::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('address.name') !!}</p>
</x-address::layouts.master>
