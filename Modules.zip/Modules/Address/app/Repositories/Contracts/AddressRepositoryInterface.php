<?php

namespace Modules\Address\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepositoryInterface;
interface AddressRepositoryInterface extends BaseRepositoryInterface
{

}
