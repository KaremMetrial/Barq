<?php

namespace Modules\Couier\Services;

use Modules\Couier\Models\ShiftTemplate;
use Modules\Couier\Models\ShiftTemplateDay;
use Illuminate\Support\Facades\DB;

class ShiftTemplateService
{
    /**
     * Get all shift templates with filters
     */
    public function getAllTemplates(array $filters = [])
    {
        $query = ShiftTemplate::with('days');

        if (isset($filters['is_active'])) {
            $query->where('is_active', $filters['is_active']);
        }

        if (isset($filters['search'])) {
            $query->where('name', 'like', '%' . $filters['search'] . '%');
        }

        return $query->latest()->paginate($filters['per_page'] ?? 15);
    }

    /**
     * Get active templates only
     */
    public function getActiveTemplates()
    {
        return ShiftTemplate::with('days')
            ->active()
            ->get();
    }

    /**
     * Create a new shift template
     */
    public function createTemplate(array $data): ShiftTemplate
    {
        return DB::transaction(function () use ($data) {
            // Create the template
            $template = ShiftTemplate::create([
                'name' => $data['name'],
                'is_active' => $data['is_active'] ?? true,
                'is_flexible' => $data['is_flexible'] ?? false,
            ]);

            // Create the days
            if (isset($data['days']) && is_array($data['days'])) {
                foreach ($data['days'] as $day) {
                    $template->days()->create([
                        'day_of_week' => $day['day_of_week'],
                        'start_time' => $day['start_time'] ?? null,
                        'end_time' => $day['end_time'] ?? null,
                        'break_duration' => $day['break_duration'] ?? 0,
                        'is_off_day' => $day['is_off_day'] ?? false,
                    ]);
                }
            }

            return $template->load('days');
        });
    }

    /**
     * Update a shift template
     */
    public function updateTemplate(int $id, array $data): ShiftTemplate
    {
        return DB::transaction(function () use ($id, $data) {
            $template = ShiftTemplate::findOrFail($id);

            // Update template info
            $template->update([
                'name' => $data['name'] ?? $template->name,
                'is_active' => $data['is_active'] ?? $template->is_active,
                'is_flexible' => $data['is_flexible'] ?? $template->is_flexible,
            ]);

            // Update days if provided
            if (isset($data['days']) && is_array($data['days'])) {
                // Delete existing days
                $template->days()->delete();

                // Create new days
                foreach ($data['days'] as $day) {
                    $template->days()->create([
                        'day_of_week' => $day['day_of_week'],
                        'start_time' => $day['start_time'] ?? null,
                        'end_time' => $day['end_time'] ?? null,
                        'break_duration' => $day['break_duration'] ?? 0,
                        'is_off_day' => $day['is_off_day'] ?? false,
                    ]);
                }
            }

            return $template->load('days');
        });
    }

    /**
     * Delete a shift template
     */
    public function deleteTemplate(int $id): bool
    {
        $template = ShiftTemplate::findOrFail($id);

        // Check if template is being used
        if ($template->courierShifts()->exists()) {
            throw new \Exception('Cannot delete template that is being used by courier shifts');
        }

        return $template->delete();
    }

    /**
     * Toggle template status
     */
    public function toggleStatus(int $id): ShiftTemplate
    {
        $template = ShiftTemplate::findOrFail($id);
        $template->update(['is_active' => !$template->is_active]);

        return $template;
    }

    /**
     * Get template by ID
     */
    public function getTemplate(int $id): ShiftTemplate
    {
        return ShiftTemplate::with('days')->findOrFail($id);
    }
}
