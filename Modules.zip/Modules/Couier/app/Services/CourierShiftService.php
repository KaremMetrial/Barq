<?php

namespace Modules\Couier\Services;

use Modules\Couier\Models\Couier;
use Modules\Couier\Models\CouierShift;
use Modules\Couier\Models\ShiftTemplate;
use Carbon\Carbon;

class CourierShiftService
{
    /**
     * Start a new shift for courier
     */
    public function startShift(int $courierId, int $templateId): CouierShift
    {
        // Check if courier has an active shift
        $activeShift = CouierShift::where('couier_id', $courierId)
            ->where('is_open', true)
            ->first();

        if ($activeShift) {
            throw new \Exception('Courier already has an active shift');
        }

        // Get template
        $template = ShiftTemplate::with('days')->findOrFail($templateId);

        if (!$template->is_active) {
            throw new \Exception('This shift template is not active');
        }

        // Get today's day configuration
        $today = Carbon::now()->dayOfWeek;
        $dayConfig = $template->getDayConfig($today);

        if (!$dayConfig) {
            throw new \Exception('No shift configuration for today');
        }

        if ($dayConfig->is_off_day) {
            throw new \Exception('Today is marked as off day in this shift template');
        }

        // Calculate expected end time
        $now = Carbon::now();
        $shiftDuration = Carbon::parse($dayConfig->end_time)->diffInMinutes(Carbon::parse($dayConfig->start_time));
        $expectedEndTime = $now->copy()->addMinutes($shiftDuration);

        // Create shift
        $shift = CouierShift::create([
            'couier_id' => $courierId,
            'shift_template_id' => $templateId,
            'start_time' => $now,
            'expected_end_time' => $expectedEndTime,
            'is_open' => true,
        ]);

        return $shift->load('shiftTemplate');
    }

    /**
     * End a shift
     */
    public function endShift(int $shiftId, float $overtimeRate = 1.5): CouierShift
    {
        $shift = CouierShift::findOrFail($shiftId);

        if (!$shift->is_open) {
            throw new \Exception('This shift is already closed');
        }

        $now = Carbon::now();

        // Calculate overtime
        $overtimeMinutes = 0;
        $overtimePay = 0;

        if ($shift->expected_end_time && $now->greaterThan($shift->expected_end_time)) {
            $overtimeMinutes = $now->diffInMinutes($shift->expected_end_time);

            // Calculate overtime pay (assuming hourly rate from courier settings)
            // You can adjust this based on your business logic
            $hourlyRate = 50; // Default rate, should come from courier settings
            $overtimePay = ($overtimeMinutes / 60) * $hourlyRate * $overtimeRate;
        }

        // Update shift
        $shift->update([
            'end_time' => $now,
            'is_open' => false,
            'overtime_minutes' => $overtimeMinutes,
            'overtime_pay' => $overtimePay,
        ]);

        return $shift->fresh();
    }

    /**
     * Start break
     */
    public function startBreak(int $shiftId): CouierShift
    {
        $shift = CouierShift::findOrFail($shiftId);

        if (!$shift->is_open) {
            throw new \Exception('Cannot start break on a closed shift');
        }

        if ($shift->break_start) {
            throw new \Exception('Break already started');
        }

        $shift->update(['break_start' => Carbon::now()]);

        return $shift->fresh();
    }

    /**
     * End break
     */
    public function endBreak(int $shiftId): CouierShift
    {
        $shift = CouierShift::findOrFail($shiftId);

        if (!$shift->is_open) {
            throw new \Exception('Cannot end break on a closed shift');
        }

        if (!$shift->break_start) {
            throw new \Exception('Break has not been started');
        }

        if ($shift->break_end) {
            throw new \Exception('Break already ended');
        }

        $shift->update(['break_end' => Carbon::now()]);

        return $shift->fresh();
    }

    /**
     * Get current active shift for courier
     */
    public function getCurrentShift(int $courierId): ?CouierShift
    {
        return CouierShift::with('shiftTemplate')
            ->where('couier_id', $courierId)
            ->where('is_open', true)
            ->first();
    }

    /**
     * Get shift history for courier
     */
    public function getShiftHistory(int $courierId, array $filters = [])
    {
        $query = CouierShift::with('shiftTemplate')
            ->where('couier_id', $courierId);

        if (isset($filters['from_date'])) {
            $query->whereDate('start_time', '>=', $filters['from_date']);
        }

        if (isset($filters['to_date'])) {
            $query->whereDate('start_time', '<=', $filters['to_date']);
        }

        if (isset($filters['is_open'])) {
            $query->where('is_open', $filters['is_open']);
        }

        return $query->latest('start_time')->paginate($filters['per_page'] ?? 15);
    }

    /**
     * Get statistics for courier
     */
    public function getStats(int $courierId, array $filters = []): array
    {
        $query = CouierShift::where('couier_id', $courierId)
            ->where('is_open', false);

        if (isset($filters['from_date'])) {
            $query->whereDate('start_time', '>=', $filters['from_date']);
        }

        if (isset($filters['to_date'])) {
            $query->whereDate('start_time', '<=', $filters['to_date']);
        }

        $shifts = $query->get();

        return [
            'total_shifts' => $shifts->count(),
            'total_hours' => round($shifts->sum(fn($s) => $s->total_hours), 2),
            'total_overtime_minutes' => $shifts->sum('overtime_minutes'),
            'total_overtime_pay' => $shifts->sum('overtime_pay'),
            'total_orders' => $shifts->sum('total_orders'),
            'total_earnings' => $shifts->sum('total_earnings'),
            'late_shifts_count' => $shifts->where('overtime_minutes', '>', 0)->count(),
            'average_hours_per_shift' => $shifts->count() > 0
                ? round($shifts->sum(fn($s) => $s->total_hours) / $shifts->count(), 2)
                : 0,
        ];
    }

    /**
     * Close shift (admin)
     */
    public function closeShift(int $shiftId): CouierShift
    {
        return $this->endShift($shiftId);
    }

    /**
     * Get all shifts (admin)
     */
    public function getAllShifts(array $filters = [])
    {
        $query = CouierShift::with(['couier', 'shiftTemplate']);

        if (isset($filters['couier_id'])) {
            $query->where('couier_id', $filters['couier_id']);
        }

        if (isset($filters['is_open'])) {
            $query->where('is_open', $filters['is_open']);
        }

        if (isset($filters['from_date'])) {
            $query->whereDate('start_time', '>=', $filters['from_date']);
        }

        if (isset($filters['to_date'])) {
            $query->whereDate('start_time', '<=', $filters['to_date']);
        }

        return $query->latest('start_time')->paginate($filters['per_page'] ?? 15);
    }
}
