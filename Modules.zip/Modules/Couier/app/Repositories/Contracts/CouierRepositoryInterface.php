<?php

namespace Modules\Couier\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepositoryInterface;
interface CouierRepositoryInterface extends BaseRepositoryInterface
{

}
