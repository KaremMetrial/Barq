<?php

namespace Modules\Couier\Http\Controllers\Admin;

use App\Traits\ApiResponse;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use Modules\Couier\Services\ShiftTemplateService;

class ShiftTemplateController extends Controller
{
    use ApiResponse;

    public function __construct(
        protected ShiftTemplateService $shiftTemplateService
    ) {}

    /**
     * Get all shift templates
     */
    public function index(Request $request): JsonResponse
    {
        $templates = $this->shiftTemplateService->getAllTemplates($request->all());

        return $this->successResponse([
            'templates' => $templates->items(),
            'pagination' => [
                'total' => $templates->total(),
                'per_page' => $templates->perPage(),
                'current_page' => $templates->currentPage(),
                'last_page' => $templates->lastPage(),
            ]
        ], __('message.success'));
    }

    /**
     * Create new shift template
     */
    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'is_active' => 'boolean',
            'is_flexible' => 'boolean',
            'days' => 'required|array|min:1',
            'days.*.day_of_week' => 'required|integer|between:0,6',
            'days.*.start_time' => 'required_if:days.*.is_off_day,false|date_format:H:i:s',
            'days.*.end_time' => 'required_if:days.*.is_off_day,false|date_format:H:i:s|after:days.*.start_time',
            'days.*.break_duration' => 'nullable|integer|min:0',
            'days.*.is_off_day' => 'boolean'
        ]);

        $template = $this->shiftTemplateService->createTemplate($request->all());

        return $this->successResponse([
            'template' => $template
        ], __('message.created'));
    }

    /**
     * Show shift template
     */
    public function show(int $id): JsonResponse
    {
        $template = $this->shiftTemplateService->getTemplate($id);

        return $this->successResponse([
            'template' => $template
        ], __('message.success'));
    }

    /**
     * Update shift template
     */
    public function update(Request $request, int $id): JsonResponse
    {
        $request->validate([
            'name' => 'sometimes|required|string|max:255',
            'is_active' => 'boolean',
            'is_flexible' => 'boolean',
            'days' => 'sometimes|array|min:1',
            'days.*.day_of_week' => 'required|integer|between:0,6',
            'days.*.start_time' => 'required_if:days.*.is_off_day,false|date_format:H:i:s',
            'days.*.end_time' => 'required_if:days.*.is_off_day,false|date_format:H:i:s|after:days.*.start_time',
            'days.*.break_duration' => 'nullable|integer|min:0',
            'days.*.is_off_day' => 'boolean'
        ]);

        $template = $this->shiftTemplateService->updateTemplate($id, $request->all());

        return $this->successResponse([
            'template' => $template
        ], __('message.updated'));
    }

    /**
     * Delete shift template
     */
    public function destroy(int $id): JsonResponse
    {
        try {
            $this->shiftTemplateService->deleteTemplate($id);
            return $this->successResponse(null, __('message.deleted'));
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), 400);
        }
    }

    /**
     * Toggle shift template status
     */
    public function toggle(int $id): JsonResponse
    {
        $template = $this->shiftTemplateService->toggleStatus($id);

        return $this->successResponse([
            'template' => $template
        ], __('message.updated'));
    }
}
