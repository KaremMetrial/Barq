<x-couier::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('couier.name') !!}</p>
</x-couier::layouts.master>
