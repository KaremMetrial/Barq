<?php

namespace Modules\Couier\Database\Seeders;

use Illuminate\Database\Seeder;

class CouierDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
