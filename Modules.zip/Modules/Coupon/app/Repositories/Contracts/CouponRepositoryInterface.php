<?php

namespace Modules\Coupon\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepositoryInterface;
interface CouponRepositoryInterface extends BaseRepositoryInterface
{

}
