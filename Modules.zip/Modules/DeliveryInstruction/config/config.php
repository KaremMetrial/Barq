<?php

return [
    'name' => 'DeliveryInstruction',
];
