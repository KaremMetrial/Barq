<?php

namespace Modules\DeliveryInstruction\Database\Seeders;

use Illuminate\Database\Seeder;

class DeliveryInstructionDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
