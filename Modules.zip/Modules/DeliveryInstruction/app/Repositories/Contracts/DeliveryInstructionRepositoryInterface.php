<?php

namespace Modules\DeliveryInstruction\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepositoryInterface;
interface DeliveryInstructionRepositoryInterface extends BaseRepositoryInterface
{

}
