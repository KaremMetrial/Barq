<?php

namespace Modules\Cart\Database\Seeders;

use Illuminate\Database\Seeder;

class CartDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
