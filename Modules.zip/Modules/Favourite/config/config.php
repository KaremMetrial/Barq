<?php

return [
    'name' => 'Favourite',
];
