<?php

use Illuminate\Support\Facades\Route;
use Modules\Favourite\Http\Controllers\FavouriteController;

