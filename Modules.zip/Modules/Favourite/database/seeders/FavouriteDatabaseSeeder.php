<?php

namespace Modules\Favourite\Database\Seeders;

use Illuminate\Database\Seeder;

class FavouriteDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
