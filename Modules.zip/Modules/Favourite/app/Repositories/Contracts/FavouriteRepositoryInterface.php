<?php

namespace Modules\Favourite\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepositoryInterface;
interface FavouriteRepositoryInterface extends BaseRepositoryInterface
{

}
