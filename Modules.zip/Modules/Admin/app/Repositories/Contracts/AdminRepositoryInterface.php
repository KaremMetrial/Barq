<?php

namespace Modules\Admin\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepositoryInterface;
interface AdminRepositoryInterface extends BaseRepositoryInterface
{

}
