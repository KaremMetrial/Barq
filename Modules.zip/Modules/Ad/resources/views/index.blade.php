<x-ad::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('ad.name') !!}</p>
</x-ad::layouts.master>
