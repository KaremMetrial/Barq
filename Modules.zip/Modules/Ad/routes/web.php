<?php

use Illuminate\Support\Facades\Route;
use Modules\Ad\Http\Controllers\AdController;
