<?php

namespace Modules\Ad\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepositoryInterface;
interface AdRepositoryInterface extends BaseRepositoryInterface
{

}
