<?php

return [
    'name' => 'Ad',
];
