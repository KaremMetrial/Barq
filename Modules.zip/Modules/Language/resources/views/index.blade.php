<x-language::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('language.name') !!}</p>
</x-language::layouts.master>
