<?php

namespace Modules\Banner\Repositories\Contracts;

use App\Repositories\Contracts\BaseRepositoryInterface;
interface BannerRepositoryInterface extends BaseRepositoryInterface
{

}
